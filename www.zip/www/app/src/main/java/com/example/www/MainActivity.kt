package com.example.myapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.www.R

class MainActivity : AppCompatActivity() {

    private lateinit var editTextLogin: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var buttonLogin: Button
    private lateinit var textViewError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        editTextLogin = findViewById(R.id.editTextText)
        editTextPassword = findViewById(R.id.editTextTextPassword)
        buttonLogin = findViewById(R.id.button)
        textViewError = findViewById(R.id.textView2)  // используем существующий TextView для ошибок


        textViewError.visibility = TextView.VISIBLE
        textViewError.text = ""

        buttonLogin.setOnClickListener {
            val login = editTextLogin.text.toString().trim()
            val password = editTextPassword.text.toString().trim()

            if (login.isEmpty()) {
                showError("Введите логин")
            } else if (password.isEmpty()) {
                showError("Введите пароль")
            } else {

                Toast.makeText(this, "Вход выполнен!", Toast.LENGTH_SHORT).show()

            }
        }
    }


    private fun showError(message: String) {
        textViewError.visibility = TextView.VISIBLE
        textViewError.text = message
        textViewError.setTextColor(getColor(android.R.color.holo_red_dark))
    }
}
