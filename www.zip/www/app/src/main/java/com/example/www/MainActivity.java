package com.example.www; // замените на ваш пакет

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextLogin;
    private EditText editTextPassword;
    private Button buttonLogin;
    private TextView textViewError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов интерфейса
        editTextLogin = findViewById(R.id.editTextText);
        editTextPassword = findViewById(R.id.editTextTextPassword);
        buttonLogin = findViewById(R.id.button);
        textViewError = findViewById(R.id.textView2);

        // Скрываем сообщение об ошибке изначально
        textViewError.setVisibility(TextView.VISIBLE);
        textViewError.setText("");

        // Обработчик нажатия кнопки "Войти"
        buttonLogin.setOnClickListener(v -> {
            String login = editTextLogin.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            if (login.isEmpty()) {
                showError("Введите логин");
            } else if (password.isEmpty()) {
                showError("Введите пароль");
            } else {
                // Если всё заполнено — выполняем вход
                Toast.makeText(this, "Вход выполнен!", Toast.LENGTH_SHORT).show();
                // Здесь можно добавить переход на другой экран:
                // Intent intent = new Intent(this, NextActivity.class);
                // startActivity(intent);
            }
        });
    }

    // Метод для отображения ошибки
    private void showError(String message) {
        textViewError.setVisibility(TextView.VISIBLE);
        textViewError.setText(message);
        textViewError.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
    }
}
