package com.example.a29_10_task1

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private var currentInput = StringBuilder()
    private var currentOperator = ""
    private var firstOperand = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
    }

    private fun initializeViews() {
        // Инициализация TextView
        textView = findViewById(R.id.textView)

        // Инициализация числовых кнопок
        val bt1: Button = findViewById(R.id.bt1)
        val bt2: Button = findViewById(R.id.bt2)
        val bt3: Button = findViewById(R.id.bt3)
        val bt4: Button = findViewById(R.id.bt4)
        val bt5: Button = findViewById(R.id.bt5)
        val bt6: Button = findViewById(R.id.bt6)
        val bt7: Button = findViewById(R.id.bt7)
        val bt8: Button = findViewById(R.id.bt8)
        val bt9: Button = findViewById(R.id.bt9)
        val bt0: Button = findViewById(R.id.bt0)

        // Инициализация кнопок операторов
        val btc: Button = findViewById(R.id.btc)
        val bte: Button = findViewById(R.id.bte)
        val btm: Button = findViewById(R.id.btm)
        val btp: Button = findViewById(R.id.btp)
        val btslay: Button = findViewById(R.id.btslay)
        val btstar: Button = findViewById(R.id.btstar)

        // Установка обработчиков для числовых кнопок
        bt0.setOnClickListener { onNumberClicked("0") }
        bt1.setOnClickListener { onNumberClicked("1") }
        bt2.setOnClickListener { onNumberClicked("2") }
        bt3.setOnClickListener { onNumberClicked("3") }
        bt4.setOnClickListener { onNumberClicked("4") }
        bt5.setOnClickListener { onNumberClicked("5") }
        bt6.setOnClickListener { onNumberClicked("6") }
        bt7.setOnClickListener { onNumberClicked("7") }
        bt8.setOnClickListener { onNumberClicked("8") }
        bt9.setOnClickListener { onNumberClicked("9") }

        // Установка обработчиков для операторов
        btp.setOnClickListener { onOperatorClicked("+") }
        btm.setOnClickListener { onOperatorClicked("-") }
        btstar.setOnClickListener { onOperatorClicked("*") }
        btslay.setOnClickListener { onOperatorClicked("/") }

        // Кнопка равно
        bte.setOnClickListener { calculateResult() }

        // Кнопка очистки
        btc.setOnClickListener { clearCalculator() }
    }

    private fun onNumberClicked(number: String) {
        // Если текущий ввод "0", заменяем его, иначе добавляем цифру
        if (currentInput.toString() == "0") {
            currentInput.clear()
        }
        currentInput.append(number)
        updateDisplay()
    }

    private fun onOperatorClicked(operator: String) {
        if (currentInput.isNotEmpty()) {
            firstOperand = currentInput.toString().toDouble()
            currentOperator = operator
            currentInput.clear()
            updateDisplay()
        }
    }

    private fun calculateResult() {
        if (currentInput.isNotEmpty() && currentOperator.isNotEmpty()) {
            val secondOperand = currentInput.toString().toDouble()
            val result = when (currentOperator) {
                "+" -> firstOperand + secondOperand
                "-" -> firstOperand - secondOperand
                "*" -> firstOperand * secondOperand
                "/" -> {
                    if (secondOperand != 0.0) {
                        firstOperand / secondOperand
                    } else {
                        // Обработка деления на ноль
                        Double.NaN
                    }
                }
                else -> return
            }

            currentInput.clear()
            if (result.isNaN()) {
                currentInput.append("Error")
            } else {
                currentInput.append(formatResult(result))
            }
            currentOperator = ""
            updateDisplay()
        }
    }

    private fun clearCalculator() {
        currentInput.clear()
        currentOperator = ""
        firstOperand = 0.0
        textView.text = "0"
    }

    private fun updateDisplay() {
        textView.text = if (currentInput.isNotEmpty()) {
            currentInput.toString()
        } else {
            "0"
        }
    }

    private fun formatResult(result: Double): String {
        return if (result % 1 == 0.0) {
            // Если число целое, убираем десятичную часть
            result.toInt().toString()
        } else {
            // Если дробное, оставляем 2 знака после запятой
            String.format("%.8f", result)
        }
    }
}